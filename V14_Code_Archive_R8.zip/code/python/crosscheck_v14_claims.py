#!/usr/bin/env python3
"""Check R8 cross-document wording, highlight limits, and figure assets."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from scan_uploadable_text import docx_text, pdf_text


WORK_ROOT = Path(__file__).resolve().parents[5]
DEFAULT_PACKAGE = WORK_ROOT / "Submission_Package_v14_R8"
DEFAULT_OUTPUT = (
    DEFAULT_PACKAGE
    / "supplementary"
    / "S13_reproducibility"
    / "manifests"
    / "cross_document_claim_check.json"
)

DOCUMENTS = {
    "Manuscript/Peripheral_Central_Overlap_Manuscript_v14_R8.docx": [
        r"Cross-Strain\s+Single-Nucleus\s+Context",
        r"GSE274279\s+was\s+reported\s+by\s+Xia\s+et\s+al\.\s+\(2025",
        r"C57BL/6J",
        r"no\s+gene\s+met\s+the\s+prespecified\s+composite\s+criterion",
        r"Seven\s+genes\s+met\s+the\s+frozen\s+rule",
        r"all\s+four\s+deposited\s+10x\s+libraries",
        r"produced\s+18\s+clusters",
        r"Variance-stabilizing\s+transformation\s+selected\s+2,500\s+variable\s+features",
        r"For\s+duplicated\s+gene\s+symbols,\s+the\s+first\s+occurrence\s+in\s+the\s+feature\s+annotation\s+was\s+retained\s+before\s+matrix\s+concatenation",
        r"animal-level\s+relationship\s+of\s+GSM8446836\s+to\s+GSM8446835\s+is\s+not\s+documented\s+in\s+GEO",
        r"14,152\s+nuclei",
        r"245\s+marker-defined\s+myeloid\s+nuclei",
        r"CellChat\s+analysis\s+used\s+a\s+three-library\s+subset\s+containing\s+GSM8446833,\s+GSM8446834,\s+and\s+GSM8446835",
        r"sex\s+adjustment\s+was\s+treated\s+as\s+limited",
        r"retained\s+all\s+seven\s+SP-versus-YC\s+intersection\s+genes",
        r"50\.0%,\s+69\.1%,\s+and\s+47\.9%",
        r"Age,\s+library,\s+and\s+10x\s+batch\s+are\s+inseparable",
        r"First-probe,\s+mean-probe,\s+and\s+highest-mean-probe",
        r"intersections\s+contained\s+seven,\s+eight,\s+and\s+nine\s+genes",
        r"Clec7a\s+was\s+not\s+detected",
        r"GSE49522\s+is\s+cited\s+by\s+its\s+GEO\s+dataset\s+record",
        r"D'Souza\s+et\s+al\.,\s+2013\s+dataset",
        r"10\.5281/zenodo\.24168471",
        r"DOI\s+10\.5281/zenodo\.23737275\s+identifies\s+Revision\s+3\s+only",
    ],
    "Manuscript/Peripheral_Central_Overlap_Manuscript_v14_R8.pdf": [
        r"Cross-Strain\s+Single-Nucleus\s+Context",
        r"C57BL/6J",
        r"no\s+gene\s+met\s+the\s+prespecified\s+composite\s+criterion",
        r"Seven\s+genes\s+met\s+the\s+frozen\s+rule",
        r"sex\s+adjustment\s+was\s+treated\s+as\s+limited",
        r"Age,\s+library,\s+and\s+10x\s+batch\s+are\s+inseparable",
        r"245\s+marker-defined\s+myeloid\s+nuclei",
        r"For\s+duplicated\s+gene\s+symbols,\s+the\s+first\s+occurrence\s+in\s+the\s+feature\s+annotation\s+was\s+retained\s+before\s+matrix\s+concatenation",
        r"10\.5281/zenodo\.24168471",
        r"DOI\s+10\.5281/zenodo\.23737275\s+identifies\s+Revision\s+3\s+only",
    ],
    "Cover_Letter/V14_Cover_Letter_R8.docx": [
        r"Research\s+Paper",
        r"Cross-Strain\s+Single-Nucleus\s+Context",
        r"no\s+gene\s+met\s+the\s+prespecified\s+composite\s+criterion",
        r"seven\s+higher-expression\s+myeloid-associated\s+genes",
        r"All\s+seven\s+core\s+genes\s+were\s+retained\s+without\s+sex\s+adjustment",
        r"All\s+four\s+deposited\s+cochlear\s+libraries",
        r"Cell-level\s+P\s+values\s+and\s+FDR\s+columns\s+were\s+removed",
        r"archived\s+in\s+Zenodo\s+at\s+https://doi\.org/10\.5281/zenodo\.24168471",
        r"10\.5281/zenodo\.24168471",
    ],
    "Cover_Letter/V14_Cover_Letter_R8.pdf": [
        r"Research\s+Paper",
        r"Cross-Strain\s+Single-Nucleus\s+Context",
        r"seven\s+higher-expression\s+myeloid-associated\s+genes",
        r"All\s+four\s+deposited\s+cochlear\s+libraries",
        r"10\.5281/zenodo\.24168471",
    ],
    "Highlights/V14_Highlights_R8.docx": [
        r"Unordered\s+labels\s+avoided\s+an\s+ordinal\s+scale;\s+age\s+and\s+hearing\s+remained\s+confounded",
        r"The\s+seven-gene\s+core\s+persisted\s+across\s+three\s+probe-aggregation\s+rules",
        r"All\s+four\s+GSE274279\s+libraries\s+provided\s+C57BL/6J\s+descriptive\s+context",
        r"Cell-level\s+P\s+values\s+were\s+not\s+used",
    ],
    "Highlights/V14_Highlights_R8.pdf": [
        r"Unordered\s+labels\s+avoided\s+an\s+ordinal\s+scale;\s+age\s+and\s+hearing\s+remained\s+confounded",
        r"The\s+seven-gene\s+core\s+persisted\s+across\s+three\s+probe-aggregation\s+rules",
        r"All\s+four\s+GSE274279\s+libraries\s+provided\s+C57BL/6J\s+descriptive\s+context",
        r"Cell-level\s+P\s+values\s+were\s+not\s+used",
    ],
    "Figure_Legends/V14_Figure_Legends_R8.docx": [
        r"Figure\s+4\.\s+Descriptive\s+candidate\s+detection\s+in\s+C57BL/6J",
        r"Figure\s+5\.\s+Sex\s+composition\s+and\s+no-sex\s+sensitivity",
        r"Supplementary\s+Figure\s+S6\.\s+Descriptive\s+atlas\s+of\s+all\s+four",
        r"does\s+not\s+provide\s+independent\s+localization",
        r"Age,\s+library,\s+and\s+10x\s+batch\s+are\s+inseparable",
        r"not\s+animal-level\s+biological-effect\s+confidence\s+intervals",
    ],
    "Figure_Legends/V14_Figure_Legends_R8.pdf": [
        r"Figure\s+4\.\s+Descriptive\s+candidate\s+detection\s+in\s+C57BL/6J",
        r"Figure\s+5\.\s+Sex\s+composition\s+and\s+no-sex\s+sensitivity",
        r"Supplementary\s+Figure\s+S6\.\s+Descriptive\s+atlas\s+of\s+all\s+four",
        r"does\s+not\s+provide\s+independent\s+localization",
    ],
    "Response_to_Reviewers/V14_Response_to_Reviewers_R8.docx": [
        r"Post-review\s+corrections\s+in\s+R8",
        r"10\.5281/zenodo\.24168471",
        r"Unordered\s+labels\s+avoided\s+an\s+ordinal\s+scale;\s+age\s+and\s+hearing\s+remained\s+confounded",
        r"For\s+duplicated\s+gene\s+symbols,\s+the\s+first\s+occurrence\s+in\s+the\s+feature\s+annotation\s+was\s+retained\s+before\s+matrix\s+concatenation",
        r"no\s+single-cell\s+recomputation\s+was\s+required",
    ],
    "Response_to_Reviewers/V14_Response_to_Reviewers_R8.pdf": [
        r"Post-review\s+corrections\s+in\s+R8",
        r"10\.5281/zenodo\.24168471",
        r"Unordered\s+labels\s+avoided\s+an\s+ordinal\s+scale;\s+age\s+and\s+hearing\s+remained\s+confounded",
        r"no\s+single-cell\s+recomputation\s+was\s+required",
    ],
}

FORBIDDEN = [
    r"seven\s+transcripts",
    r"seven\s+myeloid-associated\s+transcripts",
    r"no\s+significant\s+genes",
    r"independent\s+cochlear\s+single-nucleus\s+localization",
    r"mainly\s+to\s+macrophages/microglia",
    r"mainly\s+locali[sz]ed",
    r"Ptprc\s+had\s+no\s+usable",
    r"Clec7a,\s+Lyz1,\s+Lyz2,\s+and\s+Ptprc\s+had\s+no\s+usable",
    r"overlapping\s+transcript\s+label",
    r"three\s+10x\s+matrices",
    r"Each\s+age\s+was\s+a\s+separate\s+10x\s+matrix",
    r"52\.8%,\s+77\.0%,\s+and\s+51\.5%",
    r"clipped\s+to\s+[+-]/?2\.5",
    r"147\s+(?:unique\s+)?(?:myeloid\s+)?nuclei",
    r"\b16\s+(?:K-means\s+)?clusters?\b",
    r"not\s+an\s+animal-level\s+(?:biological\s+)?replicate",
    r"not\s+biological\s+replicates",
    r"duplicate\s+gene\s+symbols\s+were\s+collapsed",
    r"Unordered\s+cohort\s+models\s+removed\s+the\s+ordinal-severity\s+assumption;\s+age\s+and\s+hearing\s+status\s+remained\s+confounded",
    r"R8\s+DOI\s+is\s+pending",
    r"has\s+not\s+yet\s+been\s+deposited\s+as\s+a\s+Zenodo\s+version",
    r"Zenodo\s+deposit\s+and\s+DOI\s+remain\s+pending",
    r"No\s+new\s+DOI\s+is\s+claimed\s+for\s+R8",
]

FORBIDDEN_OUTSIDE_RESPONSE = [
    r"\bScanpy\b",
    r"\b15-neighbor\b",
]

FIGURE_STEMS = [
    "figure1_study_audit",
    "figure2_frozen_limma",
    "figure3_intersection_sensitivity",
    "figure4_cellular_context",
    "figure5_model_identifiability",
    "figureS1_wgcna",
    "figureS2_external_context",
    "figureS3_cellchat_age_overview",
    "figureS4_cellchat_focus",
    "figureS5_myeloid_subclustering",
    "figureS6_full_atlas",
    "graphical_abstract_v14",
]


def normalized_text(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".docx":
        text = docx_text(path)
    elif path.suffix.lower() == ".pdf":
        text = pdf_text(path)
    else:
        text = path.read_text(encoding="utf-8", errors="replace")
    text = text.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-")
    text = re.sub(r"-\s*\n\s*", "-", text)
    return re.sub(r"\s+", " ", text)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Check Revision 8 claims and retired wording."
    )
    parser.add_argument("--package", type=Path, default=DEFAULT_PACKAGE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    package = args.package.resolve()
    output_path = args.output.resolve()

    checks: list[dict] = []
    for relative, patterns in DOCUMENTS.items():
        text = normalized_text(package / relative)
        for pattern in patterns:
            matched = re.search(pattern, text, flags=re.IGNORECASE) is not None
            checks.append(
                {
                    "file": relative,
                    "kind": "required",
                    "pattern": pattern,
                    "passed": matched,
                }
            )
        forbidden_patterns = list(FORBIDDEN)
        if not relative.startswith("Response_to_Reviewers/"):
            forbidden_patterns.extend(FORBIDDEN_OUTSIDE_RESPONSE)
        for pattern in forbidden_patterns:
            matched = re.search(pattern, text, flags=re.IGNORECASE) is not None
            checks.append(
                {
                    "file": relative,
                    "kind": "forbidden",
                    "pattern": pattern,
                    "passed": not matched,
                }
            )

    highlights_path = package / "Highlights" / "V14_HIGHLIGHTS_R8.md"
    highlight_items = [
        line.removeprefix("- ").strip()
        for line in highlights_path.read_text(encoding="utf-8").splitlines()
        if line.startswith("- ")
    ]
    expected = (
        "Unordered labels avoided an ordinal scale; age and hearing remained confounded."
    )
    checks.append(
        {
            "file": "Highlights/V14_HIGHLIGHTS_R8.md",
            "kind": "highlight_length",
            "pattern": "all_items_le_85_characters",
            "passed": bool(highlight_items)
            and all(len(item) <= 85 for item in highlight_items),
            "lengths": [len(item) for item in highlight_items],
        }
    )
    checks.append(
        {
            "file": "Highlights/V14_HIGHLIGHTS_R8.md",
            "kind": "highlight_content",
            "pattern": re.escape(expected),
            "passed": expected in highlight_items,
        }
    )

    for stem in FIGURE_STEMS:
        for suffix in (".png", ".pdf"):
            relative = f"Figures/{stem}{suffix}"
            checks.append(
                {
                    "file": relative,
                    "kind": "asset",
                    "pattern": suffix,
                    "passed": (package / relative).is_file(),
                }
            )

    failures = [item for item in checks if not item["passed"]]
    passed = not failures
    output = {
        "status": "PASS" if passed else "FAIL",
        "checked_documents": len(DOCUMENTS),
        "checked_assets": len(FIGURE_STEMS) * 2,
        "checked_items": len(checks),
        "failures": failures,
        "checks": checks,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(output, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        f"cross_document_claim_check={output['status']} "
        f"items={output['checked_items']} failures={len(failures)}"
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
