#!/usr/bin/env python3
"""Build the Revision 8 code archive, compact supplement, and upload set."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[4]
SUPPLEMENT_ROOT = PACKAGE_ROOT / "supplementary"
S13_ROOT = SUPPLEMENT_ROOT / "S13_reproducibility"
MANIFEST_SCRIPT = S13_ROOT / "code" / "python" / "build_submission_manifest_r8.py"
ZIP_TIMESTAMP = (2026, 11, 13, 0, 0, 0)

CITATION_CFF = """\
cff-version: 1.2.0
message: "If you use this code or these result tables, please cite the associated manuscript and the R8 Zenodo record."
title: "Intersection of Myeloid-Associated Genes in Aging CBA/CaJ Mouse Auditory Tissues: A Secondary Reanalysis with Cross-Strain Single-Nucleus Context"
type: software
authors:
  - family-names: Ji
    given-names: Jiabiao
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Yu
    given-names: Xiaoqing
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Zhang
    given-names: Chao
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Liu
    given-names: Long
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Song
    given-names: Jun
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Yan
    given-names: Lin
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
  - family-names: Ren
    given-names: Shan
    affiliation: "The First Affiliated Hospital of Bengbu Medical University"
  - family-names: Yang
    given-names: Jianming
    affiliation: "The Second Affiliated Hospital of Anhui Medical University"
repository-code: "https://github.com/jiabiao86/presbycusis-myeloid-reanalysis"
identifiers:
  - type: doi
    value: "10.5281/zenodo.24168471"
    description: "Version DOI for the R8 archive"
keywords:
  - presbycusis
  - age-related hearing loss
  - cochlea
  - inferior colliculus
  - macrophage
  - microglia
  - transcriptomics
  - CellChat
license: MIT
version: "v14-r8"
date-released: "2026-11-13"
"""

LICENSE = """\
MIT License

Copyright (c) 2026 Jiabiao Ji, Xiaoqing Yu, Chao Zhang, Long Liu, Jun Song,
Lin Yan, Shan Ren, and Jianming Yang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Derived result tables and figure sources in this repository are additionally
made available under the Creative Commons Attribution 4.0 International License
(CC BY 4.0). The public datasets reanalyzed here (GSE49543, GSE49522, GSE233798,
GSE153882, GSE154833, GSE274279) remain subject to the terms set by their
original depositors.
"""


def require_file(path: Path) -> Path:
    if not path.is_file():
        raise FileNotFoundError(path)
    if path.stat().st_size == 0:
        raise ValueError(f"Refusing to package zero-byte file: {path}")
    return path


def copy_file(source: Path, destination: Path) -> None:
    require_file(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_tree_filtered(
    source: Path,
    destination: Path,
    *,
    skip_suffixes: set[str] | None = None,
    skip_names: set[str] | None = None,
) -> None:
    skip_suffixes = skip_suffixes or set()
    skip_names = skip_names or set()
    if not source.is_dir():
        raise FileNotFoundError(source)
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(source)
        if "__pycache__" in relative.parts:
            continue
        if path.suffix.lower() in skip_suffixes or path.name in skip_names:
            continue
        if path.name in {"GSE274279_macrophage_age_effects.csv"}:
            continue
        copy_file(path, destination / relative)


def copy_selected_flat(
    source: Path,
    destination: Path,
    names: tuple[str, ...],
) -> None:
    for name in names:
        copy_file(source / name, destination / name)


def build_code_stage(stage: Path) -> None:
    copy_file(S13_ROOT / "Code_Archive_README.md", stage / "README.md")
    copy_file(S13_ROOT / "INDEX.md", stage / "INDEX.md")
    (stage / "CITATION.cff").write_text(CITATION_CFF, encoding="utf-8")
    (stage / "LICENSE").write_text(LICENSE, encoding="utf-8")

    for source in sorted((S13_ROOT / "code" / "R").glob("*.R")):
        copy_file(source, stage / "code" / "R" / source.name)
    for source in sorted((S13_ROOT / "code" / "python").glob("*.py")):
        copy_file(source, stage / "code" / "python" / source.name)

    copy_tree_filtered(
        S13_ROOT / "environment",
        stage / "environment",
        skip_suffixes={".pyc"},
    )

    copy_file(
        SUPPLEMENT_ROOT / "S1_sample_master" / "sample_master.csv",
        stage / "results" / "primary" / "sample_master.csv",
    )

    primary_names = (
        "age_comparability.csv",
        "analysis_universe.csv",
        "contrast_table.csv",
        "model_formula.txt",
        "sample_audit.json",
        "sample_exclusion.csv",
        "shared_gene_counts.csv",
        "shared_genes.csv",
        "significant_counts.csv",
        "significant_genes_long.csv",
    )
    scenario_names = (
        "analysis_universe.csv",
        "contrast_table.csv",
        "frozen_universe_invariant_genes.csv",
        "input_checksums.csv",
        "limma_run_metadata.json",
        "model_formula.txt",
        "sample_exclusion.csv",
        "sessionInfo.txt",
        "shared_gene_counts.csv",
        "shared_genes.csv",
        "significant_counts.csv",
        "significant_genes_long.csv",
    )
    s9_root = SUPPLEMENT_ROOT / "S9_significant_and_intersection"
    copy_selected_flat(
        s9_root / "primary",
        stage / "results" / "primary",
        primary_names,
    )
    copy_tree_filtered(
        s9_root / "primary" / "design",
        stage / "results" / "primary" / "design",
    )
    for scenario in (
        "sensitivity_exclude_GSM1201568",
        "sensitivity_exclude_GSM1201602",
        "sensitivity_exclude_both_unmatched",
    ):
        copy_selected_flat(
            s9_root / scenario,
            stage / "results" / scenario,
            scenario_names,
        )
        copy_tree_filtered(
            s9_root / scenario / "design",
            stage / "results" / scenario / "design",
        )

    copy_tree_filtered(
        s9_root / "sensitivity_no_sex",
        stage / "results" / "sensitivity_no_sex",
        skip_names={"no_sex_vs_sex_adjusted_all_genes.csv"},
    )
    copy_tree_filtered(
        s9_root / "sensitivity_probe_aggregation",
        stage / "results" / "sensitivity_probe_aggregation",
        skip_names={
            "GSE49543_first_probe_log2.csv",
            "GSE49543_mean_probe_log2.csv",
            "GSE49543_max_mean_probe_log2.csv",
        },
    )
    copy_tree_filtered(
        s9_root / "sensitivity_summary",
        stage / "results" / "sensitivity_summary",
    )
    copy_tree_filtered(
        s9_root / "leave_one_animal_out",
        stage / "results" / "leave_one_animal_out",
    )

    copy_tree_filtered(
        SUPPLEMENT_ROOT / "S10_wgcna",
        stage / "results" / "primary" / "wgcna",
        skip_suffixes={".rds"},
    )

    external_root = S13_ROOT / "results" / "external"
    external_names = (
        "EXTERNAL_RESULTS_README.md",
        "external_candidate_genes.csv",
        "external_p_value_underflow.csv",
        "external_welch_manifest.json",
        "external_welch_summary.csv",
        "external_welch_validation.csv",
        "external_welch_validation.json",
        "external_welch_validation_summary.csv",
        "GSE153882_IHC_candidate_genes.csv",
        "GSE153882_OHC_candidate_genes.csv",
        "GSE154833_candidate_genes.csv",
        "GSE233798_candidate_genes.csv",
        "sessionInfo.txt",
    )
    copy_selected_flat(
        external_root,
        stage / "results" / "external",
        external_names,
    )

    cellchat_root = SUPPLEMENT_ROOT / "S12_cellchat"
    copy_tree_filtered(
        cellchat_root,
        stage / "inputs" / "prepared" / "cellchat_full",
    )

    single_cell_root = SUPPLEMENT_ROOT / "S11_myeloid_cell_audit"
    copy_file(
        single_cell_root / "README.md",
        stage / "inputs" / "single_cell" / "GSE274279_source" / "README.md",
    )
    for name in ("GSE274279_source_manifest.csv", "GSE274279_source_files_sha256.csv"):
        copy_file(
            single_cell_root / name,
            stage / "inputs" / "single_cell" / "GSE274279_source" / name,
        )
    copy_tree_filtered(
        single_cell_root / "gse274279_four_matrix",
        stage / "results" / "single_cell" / "GSE274279_four_matrix",
        skip_suffixes={".rds"},
    )

    validation_root = S13_ROOT / "validation"
    copy_file(
        validation_root / "VALIDATION_REPORT.md",
        stage / "validation" / "VALIDATION_REPORT.md",
    )
    copy_file(
        validation_root / "geo_rebuild" / "geo_preparation_manifest.json",
        stage / "validation" / "geo_preparation_manifest.json",
    )
    for rebuild in ("primary_rebuild", "sensitivity_rebuild"):
        source = validation_root / rebuild
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(source)
            if (
                path.suffix.lower() == ".rds"
                or relative.parts[0] == "limma"
                or "__pycache__" in relative.parts
            ):
                continue
            copy_file(
                path,
                stage / "validation" / rebuild / relative,
            )

    subprocess.run(
        [
            sys.executable,
            str(MANIFEST_SCRIPT),
            "--package",
            str(stage),
            "--output-dir",
            str(stage / "manifests"),
        ],
        check=True,
    )


def build_compact_stage(stage: Path) -> None:
    copy_file(
        SUPPLEMENT_ROOT / "00_Supplementary_Index.md",
        stage / "00_Supplementary_Index.md",
    )
    copy_file(
        SUPPLEMENT_ROOT / "V14_Supplementary_Index_R8.md",
        stage / "V14_Supplementary_Index_R8.md",
    )

    for section in (
        "S1_sample_master",
        "S2_model_and_contrasts",
        "S3_limma",
        "S4_limma",
        "S5_limma",
        "S6_limma",
        "S7_limma",
        "S8_limma",
    ):
        copy_tree_filtered(
            SUPPLEMENT_ROOT / section,
            stage / section,
            skip_suffixes={".rds"},
        )

    s9_root = SUPPLEMENT_ROOT / "S9_significant_and_intersection"
    copy_file(s9_root / "README.md", stage / "S9_significant_and_intersection" / "README.md")
    for name in ("leave_one_animal_out", "sensitivity_summary"):
        copy_tree_filtered(
            s9_root / name,
            stage / "S9_significant_and_intersection" / name,
        )
    for result_set in (
        "primary",
        "sensitivity_exclude_GSM1201568",
        "sensitivity_exclude_GSM1201602",
        "sensitivity_exclude_both_unmatched",
    ):
        source = s9_root / result_set
        destination = stage / "S9_significant_and_intersection" / result_set
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(source)
            if (
                path.suffix.lower() == ".rds"
                or relative.parts[0] == "limma"
                or path.name in {
                    "cross_document_claim_check.json",
                    "uploadable_content_scan.txt",
                    "GSE274279_macrophage_age_effects.csv",
                }
            ):
                continue
            copy_file(path, destination / relative)

    copy_tree_filtered(
        s9_root / "sensitivity_no_sex",
        stage / "S9_significant_and_intersection" / "sensitivity_no_sex",
        skip_names={"no_sex_vs_sex_adjusted_all_genes.csv"},
    )
    copy_tree_filtered(
        s9_root / "sensitivity_probe_aggregation",
        stage / "S9_significant_and_intersection" / "sensitivity_probe_aggregation",
        skip_names={
            "GSE49543_first_probe_log2.csv",
            "GSE49543_mean_probe_log2.csv",
            "GSE49543_max_mean_probe_log2.csv",
        },
    )

    copy_tree_filtered(
        SUPPLEMENT_ROOT / "S10_wgcna",
        stage / "S10_wgcna",
        skip_suffixes={".rds"},
    )
    copy_tree_filtered(
        SUPPLEMENT_ROOT / "S11_myeloid_cell_audit",
        stage / "S11_myeloid_cell_audit",
        skip_suffixes={".rds"},
    )
    copy_tree_filtered(
        SUPPLEMENT_ROOT / "S12_cellchat",
        stage / "S12_cellchat",
    )

    copy_file(
        S13_ROOT / "Code_Archive_README.md",
        stage / "S13_reproducibility" / "CODE_ARCHIVE_README.md",
    )
    copy_file(
        S13_ROOT / "INDEX.md",
        stage / "S13_reproducibility" / "INDEX.md",
    )
    copy_file(
        S13_ROOT / "validation" / "VALIDATION_REPORT.md",
        stage / "S13_reproducibility" / "VALIDATION_REPORT.md",
    )
    copy_file(
        S13_ROOT / "manifests" / "cross_document_claim_check.json",
        stage / "S13_reproducibility" / "cross_document_claim_check.json",
    )
    copy_file(
        S13_ROOT / "manifests" / "uploadable_content_scan.txt",
        stage / "S13_reproducibility" / "uploadable_content_scan.txt",
    )

    readme = """# V14 Revision 8 Compact Supplementary Materials

This archive contains the reviewable S1-S13 summary layer for Revision 8:
complete S1-S8 source tables, selected S9 primary and sensitivity summaries,
S10 WGCNA summaries, the four-library S11 GSE274279 descriptive audit, S12
three-library CellChat summaries, and the S13 code-index and validation
records.

The archive excludes public GEO workbooks, complete prepared matrices, large
R objects, duplicate complete sensitivity result tables, and the complete
transcriptome-wide Welch/BH tables. The separate
`V14_Code_Archive_R8.zip` contains scripts and selected outputs needed to
rebuild omitted files from the cited public records.

GSE274279 is the C57BL/6J dataset reported by Xia et al. (2025). All four
cochlear libraries are represented in S11; CellChat in S12 uses only
GSM8446833, GSM8446834, and GSM8446835. The single-nucleus results are
cross-strain descriptive context, not CBA/CaJ validation or animal-level age
effects.
"""
    (stage / "README.md").write_text(readme, encoding="utf-8")

    subprocess.run(
        [
            sys.executable,
            str(MANIFEST_SCRIPT),
            "--package",
            str(stage),
            "--output-dir",
            str(stage),
        ],
        check=True,
    )


def write_zip(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".part")
    with zipfile.ZipFile(
        temporary,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(relative, date_time=ZIP_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (path.stat().st_mode & 0xFFFF) << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    os.replace(temporary, output)


def publish_directory(stage: Path, destination: Path, audit_root: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        audit_root.mkdir(parents=True, exist_ok=True)
        prior = audit_root / f"previous_{destination.name}"
        suffix = 1
        while prior.exists():
            prior = audit_root / f"previous_{destination.name}_{suffix}"
            suffix += 1
        destination.rename(prior)
    shutil.copytree(stage, destination)


def build_upload_stage(stage: Path, code_zip: Path, compact_zip: Path) -> None:
    copy_file(
        code_zip,
        stage / "Code_Archive" / "V14_Code_Archive_R8.zip",
    )
    for relative in (
        "Cover_Letter/V14_Cover_Letter_R8.docx",
        "Cover_Letter/V14_Cover_Letter_R8.pdf",
        "Figure_Legends/V14_Figure_Legends_R8.docx",
        "Figure_Legends/V14_Figure_Legends_R8.pdf",
        "Highlights/V14_Highlights_R8.docx",
        "Highlights/V14_Highlights_R8.pdf",
        "Manuscript/Peripheral_Central_Overlap_Manuscript_v14_R8.docx",
        "Manuscript/Peripheral_Central_Overlap_Manuscript_v14_R8.pdf",
    ):
        copy_file(PACKAGE_ROOT / relative, stage / relative)

    for number in range(1, 6):
        source = next((PACKAGE_ROOT / "Figures").glob(f"figure{number}_*.pdf"))
        copy_file(source, stage / "Figures" / source.name)
    for name in (
        "graphical_abstract_v14.pdf",
        "graphical_abstract_v14.png",
        "graphical_abstract_v14.tiff",
    ):
        copy_file(PACKAGE_ROOT / "Figures" / name, stage / "Figures" / name)

    copy_file(compact_zip, stage / "Supplementary_R8_Compact.zip")
    subprocess.run(
        [
            sys.executable,
            str(MANIFEST_SCRIPT),
            "--package",
            str(stage),
            "--output-dir",
            str(stage),
            "--path-prefix",
            "Submission_Files_R8",
        ],
        check=True,
    )


def main() -> int:
    audit_root = PACKAGE_ROOT / "R8_Internal_Audit"
    code_zip = PACKAGE_ROOT / "Code_Archive" / "V14_Code_Archive_R8.zip"
    upload_destination = PACKAGE_ROOT / "Submission_Files_R8"

    with tempfile.TemporaryDirectory(prefix="v14_r8_package_") as temporary:
        temporary_root = Path(temporary)
        code_stage = temporary_root / "code_archive"
        compact_stage = temporary_root / "compact_supplement"
        upload_stage = temporary_root / "submission_files"
        compact_zip = temporary_root / "Supplementary_R8_Compact.zip"
        build_code_stage(code_stage)
        write_zip(code_stage, code_zip)
        build_compact_stage(compact_stage)
        write_zip(compact_stage, compact_zip)
        build_upload_stage(upload_stage, code_zip, compact_zip)
        publish_directory(upload_stage, upload_destination, audit_root)

    subprocess.run(
        [
            sys.executable,
            str(MANIFEST_SCRIPT),
            "--package",
            str(PACKAGE_ROOT),
        ],
        check=True,
    )
    print(f"Wrote {code_zip}")
    print(f"Wrote {upload_destination / 'Supplementary_R8_Compact.zip'}")
    print(f"Published {upload_destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
