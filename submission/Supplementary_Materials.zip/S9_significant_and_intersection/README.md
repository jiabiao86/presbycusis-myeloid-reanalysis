# S9 Significant-Gene and Intersection Results

## Primary analysis

The `primary/` folder contains primary significant-gene counts, long-form
significant rows, SP-versus-YC intersection tables, the analysis universe,
contrast definitions, and model metadata. The primary cochlea contained 41
samples and the inferior colliculus contained 39.

## Sample-scenario analyses

The complete local audit package contains full diagnostics and limma/eBayes
tables for the three cochlear sample scenarios. The compact submission ZIP
retains the scenario summaries, intersection membership, and diagnostic
metadata needed to verify the reported comparisons:

- `sensitivity_exclude_GSM1201568/`: exclude the unmatched YC record and
  retain GSM1201602 (40 cochlear samples).
- `sensitivity_exclude_GSM1201602/`: exclude the unmatched SP record and
  retain GSM1201568 (40 cochlear samples).
- `sensitivity_exclude_both_unmatched/`: exclude both unmatched records
  (39 cochlear samples).

The primary 12,437-gene universe, unordered cohort model, sex adjustment,
contrasts, and significance thresholds were held fixed.

## No-sex sensitivity

The complete local audit package contains full result tables from an analysis
using `~ 0 + cohort_group` without sex. The compact submission ZIP retains the
design summaries, intersection membership, concordance checks, significant-gene
summary, and metadata. The 12,437-gene universe, contrasts, limma/eBayes
settings, BH procedure, and thresholds were unchanged. All seven SP-versus-YC
intersection genes were retained with the same direction; none was gained or
lost. The sex-adjusted and no-sex log2 fold changes had Spearman correlations
of 0.989 in the cochlea and 0.985 in the inferior colliculus.

## Probe-aggregation sensitivity

The `sensitivity_probe_aggregation/` folder contains complete cochlear
SP-versus-YC limma/eBayes tables under three GSE49543 probe-to-symbol rules and
the resulting intersections with the fixed inferior-colliculus result. The
rules select the first valid source-row probe, average all probes in linear
signal space, or select the probe with the highest across-sample mean linear
signal before log2 transformation.

| Rule | Cochlea significant up/down | Intersection | Seven core retained | Additional genes |
|---|---:|---:|---:|---|
| First probe | 16/2 | 7 | 7 | None |
| Mean probe | 14/2 | 8 | 7 | C1qb |
| Highest-mean probe | 17/4 | 9 | 7 | Laptm5; Ms4a6d |

The inferior-colliculus result remained fixed at 46 significant genes. The
seven-gene core is stable to probe selection, but the size and full membership
of the broader intersection are not. Source matrices, probe audit, manifests,
pairwise concordance, and session information are included.

## Intersection and leave-one-animal-out results

The primary SP-versus-YC intersection contained seven genes. Excluding
GSM1201568 alone yielded eight genes because `Tyrobp` crossed the effect-size
threshold. Excluding GSM1201602 alone yielded five genes. Excluding both
unmatched records yielded seven genes. Across 41 leave-one-animal-out models,
the intersection contained 5-10 genes (median 7).

The `sensitivity_summary/` folder contains scenario-level counts, gene
membership, the leave-one-animal-out size distribution, and session
information. The `leave_one_animal_out/` folder contains per-animal counts,
gene frequencies, and the summary JSON. These results are descriptive because
the two tissues were fitted separately without a tissue-by-cohort term or an
animal-level block effect.
