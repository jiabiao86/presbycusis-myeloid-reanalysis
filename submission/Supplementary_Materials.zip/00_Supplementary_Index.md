# Supplementary Materials Index

All paths are relative to this supplementary archive. Every item is cited in
the manuscript.

| Item | Archive path | Concise caption |
|---|---|---|
| S1 | `S1_sample_master/sample_master.csv` | Animal-level audit with reported, adjudicated, and analysis cohort labels. Unavailable phenotypes are `NA`. Animal 13 is the unmatched SP record and animal 16 is the unmatched YC record. |
| S2 | `S2_model_and_contrasts/` | Frozen model formula, contrast definitions, primary and sensitivity design matrices, rank checks, and group-by-sex counts. |
| S3 | `S3_limma/cochlea_MA_vs_YC.csv` | Complete primary limma/eBayes result table for MA versus YC in cochlea. |
| S4 | `S4_limma/cochlea_SP_vs_MP.csv` | Complete primary limma/eBayes result table for SP versus MP in cochlea. |
| S5 | `S5_limma/cochlea_SP_vs_YC.csv` | Complete primary limma/eBayes result table for SP versus YC in cochlea. |
| S6 | `S6_limma/inferior_colliculus_MA_vs_YC.csv` | Complete primary limma/eBayes result table for MA versus YC in inferior colliculus. |
| S7 | `S7_limma/inferior_colliculus_SP_vs_MP.csv` | Complete primary limma/eBayes result table for SP versus MP in inferior colliculus. |
| S8 | `S8_limma/inferior_colliculus_SP_vs_YC.csv` | Complete primary limma/eBayes result table for SP versus YC in inferior colliculus. |
| S9 | `S9_significant_and_intersection/` | Primary and sample-scenario results, no-sex sensitivity, GSE49543 probe-aggregation sensitivity, exclusion records, intersection membership, and 41 leave-one-animal-out results. |
| S10 | `S10_wgcna/` | WGCNA parameters, module assignments, eigengenes, module-level tests, rebuild summary, and checksums. |
| S11 | `S11_myeloid_cell_audit/` | Source manifest and checksums for all four GSE274279 10x matrices; per-library QC; 14,152-nucleus atlas summaries; 245 marker-defined myeloid nuclei; descriptive age and library detection summaries; and Seurat subclustering outputs. |
| S12 | `S12_cellchat/` | CellChat summary, significant inferred interactions, pathways, focus interactions, and interpretation-limit statement. |
| S13 | `S13_reproducibility/` | Code index, validation report, and external Welch/BH audit records. The separate `Analysis_Code.zip` contains scripts, environment records, selected outputs, and checksums. |

## Notes

- S3-S8 contain the six complete primary result tables. S9 contains the
  corresponding sensitivity summaries.
- S9 distinguishes the 41-sample primary analysis from exclusion of
  GSM1201568, exclusion of GSM1201602, exclusion of both unmatched records,
  41 leave-one-animal-out models, and the no-sex sensitivity analysis.
- GSE49543 first-probe, mean-probe, and highest-mean-probe intersections
  contained 7, 8, and 9 genes; all seven primary intersection genes were
  retained.
- S11 includes GSM8446833/34/35/36. GSM8446836 is a second public 24-month
  cochlear library whose animal-level relationship to GSM8446835 is not
  documented in GEO.
- Public-facing S11 age and library summaries are descriptive. Cell-level P
  values and FDR estimates are not included.
- S12 contains model-inferred interactions. It does not provide evidence of
  measured signaling, signal flux, or CD74 dependence.
- S12 uses only GSM8446833, GSM8446834, and GSM8446835, not GSM8446836.
- S12 reports zero P values as `<2.2e-16` in the interpretation file and in
  the `pval_display` field. The numeric `pval` field is retained for checking.
- Supplementary Figures S1-S6 are provided with the standalone Figure Legends
  document.
- The analysis code and selected frozen results are available at
  https://github.com/jiabiao86/presbycusis-myeloid-reanalysis and
  https://doi.org/10.5281/zenodo.24169355.
