# Supplementary Materials

This archive contains the reviewable S1-S13 tables, source records, and
summary outputs for the manuscript "Intersection of Myeloid-Associated Genes
in Aging CBA/CaJ Mouse Auditory Tissues: A Secondary Reanalysis with
Cross-Strain Single-Nucleus Context".

The archive includes the animal-level audit, model and contrast records,
complete primary limma tables, sample and probe sensitivity summaries, WGCNA
outputs, four-library GSE274279 descriptive audit, three-library CellChat
summaries, validation records, and an index to the separate
`Analysis_Code.zip`.

Public GEO workbooks, complete prepared matrices, large R objects, duplicate
complete sensitivity tables, and complete transcriptome-wide Welch/BH tables
are not redistributed. The analysis code archive contains the scripts needed
to rebuild those files from the cited public records.

GSE274279 is the C57BL/6J dataset reported by Xia et al. (2025). All four
cochlear libraries are represented in S11; CellChat in S12 uses only
GSM8446833, GSM8446834, and GSM8446835. The single-nucleus results are
cross-strain descriptive context, not CBA/CaJ validation or animal-level age
effects.
