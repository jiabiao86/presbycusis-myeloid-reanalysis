#!/usr/bin/env python3

from __future__ import annotations

import argparse
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

from pypdf import PdfReader


PACKAGE_ROOT = Path(__file__).resolve().parents[4]
DEFAULT_PACKAGE = PACKAGE_ROOT
DEFAULT_OUTPUT = (
    PACKAGE_ROOT
    / "supplementary"
    / "S13_reproducibility"
    / "manifests"
    / "uploadable_content_scan.txt"
)

TERMS = {
    "convergence": re.compile(r"\bconverg\w*", re.IGNORECASE),
    "myeloid axis": re.compile(r"\bmyeloid[\s-]+axis\b", re.IGNORECASE),
    "severity effect": re.compile(r"\bseverity[\s-]+effects?\b", re.IGNORECASE),
    "CD74-dependent": re.compile(r"\bCD74[\s-]+dependent\b", re.IGNORECASE),
    "legacy 48-gene count": re.compile(r"\b48[\s-]+genes?\b", re.IGNORECASE),
    "legacy 181-gene count": re.compile(r"\b181[\s-]+genes?\b", re.IGNORECASE),
    "legacy 48/181 count": re.compile(r"\b48\s*(?:/|and)\s*181\b", re.IGNORECASE),
    "causal direction": re.compile(r"\bcausal(?:ly)?\b", re.IGNORECASE),
    "legacy version marker": re.compile(r"\bV13\b"),
    "retired transcript wording": re.compile(
        r"\bseven\s+(?:myeloid-associated\s+)?transcripts\b", re.IGNORECASE
    ),
    "retired transcript label": re.compile(
        r"\boverlapping\s+transcript\s+label\b", re.IGNORECASE
    ),
    "retired null wording": re.compile(
        r"\bno\s+significant\s+genes\b", re.IGNORECASE
    ),
    "retired Ptprc explanation": re.compile(
        r"Ptprc\s+had\s+no\s+usable", re.IGNORECASE
    ),
    "retired localization claim": re.compile(
        r"\bmainly\s+locali[sz]ed\b", re.IGNORECASE
    ),
    "stale revision marker": re.compile(
        r"\bRevision\s+5\b|\bV14[_-]R5\b|"
        r"\bSubmission_Files_R(?:5|7)\b|\bV14_Code_Archive_R(?:5|7)\b|"
        r"\bSupplementary_R(?:5|7)_Compact\b|"
        r"\bV14_R(?:5|7)_(?:ANALYSIS_MANIFEST|SHA256SUMS|CORRECTION_LOG|REPLACED_FILES)\b|"
        r"\bbuild_submission_(?:docs|manifest|archives)_r(?:5|7)\b|"
        r"\bPeripheral_Central_Overlap_Manuscript_v14_R(?:5|7)\.(?:docx|pdf)\b|"
        r"\bV14_(?:Cover_Letter|Highlights|Figure_Legends|Response_to_Reviewers)_R(?:5|7)\.(?:docx|pdf)\b",
        re.IGNORECASE,
    ),
    "displayed exact-zero P value": re.compile(
        r"\b[Pp]\s*=\s*0(?:\.0+)?(?=\s*[;,)]|$)|,\s*p\s+0(?=[);])"
    ),
    "legacy ordinal-severity model": re.compile(
        r"\bmodels?\s+(?:the\s+study\s+as\s+)?ordinal\s+presbycusis\s+severity\b",
        re.IGNORECASE,
    ),
    "ambiguous old sample label": re.compile(
        r"\bold\s+(?:severe|mild)(?:-hearing)?\s+animals?\b", re.IGNORECASE
    ),
    "ambiguous old-mild comparison": re.compile(
        r"either\s+old\s+mild-hearing\s+comparison", re.IGNORECASE
    ),
    "unrevised threshold wording": re.compile(
        r"\bwithout\s+threshold\s+adjustment\b", re.IGNORECASE
    ),
    "internal revision history": re.compile(
        r"\bV13\s+(?:file|ordinal\s+severity)\b", re.IGNORECASE
    ),
    "internal status marker": re.compile(
        r"funding\s+statement\s+requires\s+confirmation|"
        r"(?:DOI\s+will\s+be|will\s+be)\s+inserted|"
        r"not\s+submission-ready|repository\s+identifier|"
        r"cannot\s+be\s+fully\s+reproduced|internal\s+audit",
        re.IGNORECASE,
    ),
    "retired three-matrix wording": re.compile(
        r"\bthree\s+10x\s+matrices\b", re.IGNORECASE
    ),
    "retired myeloid-count wording": re.compile(
        r"\b53,\s*61,\s*and\s*33\b", re.IGNORECASE
    ),
    "retired duplicate-symbol wording": re.compile(
        r"duplicate\s+gene\s+symbols\s+were\s+collapsed", re.IGNORECASE
    ),
    "retired Highlight wording": re.compile(
        r"Unordered\s+cohort\s+models\s+removed\s+the\s+ordinal-severity\s+assumption",
        re.IGNORECASE,
    ),
    "retired clipped-scale wording": re.compile(
        r"clipped\s+to\s+[+-]/?2\.5", re.IGNORECASE
    ),
    "retired supplementary figure label": re.compile(
        r"\bFigure\s+6\b", re.IGNORECASE
    ),
    "absolute machine path": re.compile(
        r"(?:/Users/|/home/|[A-Za-z]:\\Users\\)"
    ),
    "Unicode em/en dash in narrative": re.compile(r"[\u2013\u2014]"),
    "Unicode minus in narrative": re.compile(r"\u2212"),
}

QA_SOURCE_NAMES = {
    "crosscheck_v14_claims.py",
    "scan_uploadable_text.py",
    "V14_R8_CORRECTION_LOG.md",
    "V14_R8_REPLACED_FILES.csv",
}


def docx_text(path: Path) -> str:
    chunks: list[str] = []
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if not name.startswith("word/") or not name.endswith(".xml"):
                continue
            try:
                root = ElementTree.fromstring(archive.read(name))
            except ElementTree.ParseError:
                continue
            for node in root.iter():
                if node.tag.endswith("}t") and node.text:
                    chunks.append(node.text)
    return "\n".join(chunks)


def pdf_text(path: Path) -> str:
    reader = PdfReader(path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def file_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return docx_text(path)
    if suffix == ".pdf":
        return pdf_text(path)
    if suffix in {".md", ".txt", ".csv"}:
        with path.open("rb") as handle:
            if b"\x00" in handle.read(8192):
                return ""
        return path.read_text(encoding="utf-8", errors="replace")
    return ""


def uploadable_files(package: Path) -> list[Path]:
    files: list[Path] = []
    text_suffixes = {
        ".docx", ".pdf", ".md", ".txt", ".csv", ".json",
        ".R", ".py", ".sh", ".yaml", ".yml",
    }
    for path in package.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(package)
        if relative.parts and "Internal_Audit" in relative.parts[0]:
            continue
        if path.suffix in text_suffixes:
            files.append(path)
    return sorted(files)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Scan V14 R8 packaged text for prohibited legacy wording."
    )
    parser.add_argument("--package", type=Path, default=DEFAULT_PACKAGE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    package = args.package.resolve()
    output_path = args.output.resolve()

    findings: list[tuple[str, str, str]] = []
    paths = [
        path
        for path in uploadable_files(package)
        if path.resolve() != output_path and path.name not in QA_SOURCE_NAMES
    ]
    for path in paths:
        relative = path.relative_to(package)
        is_figure_asset = any(
            part.lower() == "figures" for part in relative.parts
        ) or (
            "source" in relative.parts
            and path.suffix.lower() in {".pdf", ".png", ".tiff"}
        )
        text = file_text(path)
        compact = re.sub(r"\s+", " ", text)
        for label, pattern in TERMS.items():
            if is_figure_asset and label.startswith("Unicode "):
                continue
            for match in pattern.finditer(compact):
                start = max(0, match.start() - 80)
                end = min(len(compact), match.end() + 80)
                findings.append(
                    (
                        relative.as_posix(),
                        label,
                        compact[start:end].strip(),
                    )
                )

    lines = [
        "V14 uploadable-content scan",
        f"Scanned files: {len(paths)}",
        f"Findings: {len(findings)}",
        "",
    ]
    if findings:
        for path, label, context in findings:
            lines.extend(
                [
                    f"FILE: {path}",
                    f"TERM: {label}",
                    f"CONTEXT: {context}",
                    "",
                ]
            )
    else:
        lines.append("PASS: no prohibited legacy or unsupported claim terms found.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
